const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect("mongodb://127.0.0.1:27017/airbnb");

app.get("/", (req, res) => {
  res.send("Server Running");
});

app.listen(5000, () => console.log("Server started on 5000"));